package com.fatec.model;

import jakarta.persistence.*;
import java.util.Date;

@Entity
@Table(name = "tb_logs")
public class Log {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String metodo; // Exemplo: "POST", "GET", "PUT", "DELETE"

    @Column(nullable = false)
    private String endpoint; // O endpoint que foi acessado

    @Column(nullable = false)
    private int status; // O status HTTP da resposta (ex: 200, 400, 404, etc.)

    @Column(nullable = false)
    private String usuario; // O nome de usuário ou ID do usuário que fez a requisição (pode ser o email ou ID)

    @Column
    private String corpoRequisicao; // O corpo da requisição (caso necessário)

    @Column
    private String corpoResposta; // O corpo da resposta (caso necessário)

    @Column
    private String ipCliente; // O IP de onde a requisição foi feita

    @Column(nullable = false)
    private Date dataHora; // A data e hora da requisição

    // Getters e Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMetodo() {
        return metodo;
    }

    public void setMetodo(String metodo) {
        this.metodo = metodo;
    }

    public String getEndpoint() {
        return endpoint;
    }

    public void setEndpoint(String endpoint) {
        this.endpoint = endpoint;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getCorpoRequisicao() {
        return corpoRequisicao;
    }

    public void setCorpoRequisicao(String corpoRequisicao) {
        this.corpoRequisicao = corpoRequisicao;
    }

    public String getCorpoResposta() {
        return corpoResposta;
    }

    public void setCorpoResposta(String corpoResposta) {
        this.corpoResposta = corpoResposta;
    }

    public String getIpCliente() {
        return ipCliente;
    }

    public void setIpCliente(String ipCliente) {
        this.ipCliente = ipCliente;
    }

    public Date getDataHora() {
        return dataHora;
    }

    public void setDataHora(Date dataHora) {
        this.dataHora = dataHora;
    }
}
