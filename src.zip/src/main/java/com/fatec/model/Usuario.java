package com.fatec.model;

import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

// A anotação @Entity indica que a classe é uma entidade JPA, ou seja, ela será mapeada para uma tabela no banco de dados.
@Entity
// A anotação @Table define o nome da tabela que será associada a esta entidade no banco de dados.
@Table(name = "tb_usuarios")
public class Usuario {

	// A anotação @Id marca o campo como a chave primária da tabela
	@Id
	// A anotação @GeneratedValue define como o ID será gerado. O valor será gerado automaticamente pelo banco de dados.
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	// A anotação @NotBlank garante que o atributo não pode ser vazio.
	@NotBlank(message = "O atributo Nome é obrigatório.")
	private String nome;

	// A anotação @Schema é usada para gerar documentação da API com o Swagger. O atributo "example" especifica um exemplo do valor para esse campo.
	@Schema(example = "email@email.com.br")
	// @NotBlank valida que o atributo não pode ser vazio.
	// @Email garante que o valor fornecido seja um e-mail válido.
	@NotBlank(message = "O atributo Usuário é obrigatório")
	@Email(message = "O atributo Usuário deve ser um email válido")
	private String usuario;

	// A anotação @NotBlank valida que o atributo senha não pode ser vazio.
	// A anotação @Size(min = 8) valida que a senha deve ter pelo menos 8 caracteres.
	@NotBlank(message = "O atributo senha é obrigatório.")
	@Size(min = 8)
	private String senha;

	private String codigoVerificacao;
	private boolean codigoValidado;

	private Date data_atualizacao;

	private Date data_criacao;

	@OneToMany(mappedBy = "usuario", cascade = CascadeType.ALL, orphanRemoval = true)
	@JsonIgnore
	private List<Dependente> dependentes;


	@PrePersist
	public void prePersist() {
		if (this.data_criacao == null) {
			this.data_criacao = new Date();
		}
		this.data_atualizacao = new Date();
	}

	@PreUpdate
	public void preUpdate() {
		this.data_atualizacao = new Date();
	}


	// Getters e setters para acessar e modificar os valores dos atributos


	public String getCodigoVerificacao() {
		return codigoVerificacao;
	}

	public void setCodigoVerificacao(String codigoVerificacao) {
		this.codigoVerificacao = codigoVerificacao;
	}

	public boolean isCodigoValidado() {
		return codigoValidado;
	}

	public void setCodigoValidado(boolean codigoValidado) {
		this.codigoValidado = codigoValidado;
	}

	public List<Dependente> getDependentes() {
		return dependentes;
	}

	public void setDependentes(List<Dependente> dependentes) {
		this.dependentes = dependentes;
	}

	public Date getData_atualizacao() {
		return data_atualizacao;
	}

	public void setData_atualizacao(Date data_atualizacao) {
		this.data_atualizacao = data_atualizacao;
	}

	public Date getData_criacao() {
		return data_criacao;
	}

	public void setData_criacao(Date data_criacao) {
		this.data_criacao = data_criacao;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

}
