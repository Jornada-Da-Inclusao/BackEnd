// Define o pacote onde o controlador está localizado.
package com.fatec.controller;

// Importações necessárias para manipulação de dados e requisições HTTP
import java.util.Optional;
import java.util.concurrent.atomic.AtomicReference;

import com.fatec.dto.UsuarioUpdateDTO;
import com.fatec.service.EmailService;
import com.fatec.service.LogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.fatec.model.Usuario;
import com.fatec.model.UsuarioLogin;
import com.fatec.repository.UsuarioRepository;
import com.fatec.service.UsuarioService;

import jakarta.validation.Valid;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

// Anotação que indica que esta classe será um controlador REST no Spring.
@RestController
// Define o caminho base para as requisições de endpoints dessa classe.
@RequestMapping("/usuarios")
// Permite requisições de qualquer origem (CORS), ou seja, qualquer domínio pode consumir os endpoints dessa API.
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class UsuarioController {

	// O Spring vai automaticamente injetar as dependências necessárias.
	@Autowired
	private UsuarioService usuarioService;

	@Autowired
	private LogService logService;

	@Autowired
	private UsuarioRepository usuarioRepository;

	@Autowired
	private RabbitTemplate rabbitTemplate;

	@Autowired
	private EmailService emailService;

	// Endpoint para buscar um usuário pelo ID
	@GetMapping("/{id}")
	public ResponseEntity<Usuario> getById(@PathVariable Long id) {
		// Tenta encontrar o usuário no banco de dados.
		return usuarioRepository.findById(id)
				// Se o usuário for encontrado, retorna com o status 200 OK e o usuário.
				.map(resposta -> ResponseEntity.ok(resposta))
				// Caso contrário, retorna 404 NOT FOUND.
				.orElse(ResponseEntity.status(HttpStatus.NOT_FOUND).build());
	}

	// Dentro do seu método
	@PostMapping("/cadastrar")
	public ResponseEntity<Usuario> postUsuario(@Valid @RequestBody Usuario usuario,
											   @RequestHeader("X-Forwarded-For") String ip) {
		// Salva o log da requisição
		String corpoRequisicao = usuario.toString(); // Pode ser interessante converter para um formato mais legível
		AtomicReference<String> corpoResposta = new AtomicReference<>("");  // Usando AtomicReference para contornar a limitação

		// Chama o serviço para cadastrar o usuário e retorna a resposta apropriada
		ResponseEntity<Usuario> response = usuarioService.cadastrarUsuario(usuario)
				.map(resposta -> {
					// Salva o corpo da resposta quando a operação for bem-sucedida
					corpoResposta.set(resposta.toString());  // Modifica o valor usando set
					logService.registrarLog("POST", "/cadastrar", HttpStatus.CREATED.value(),
							usuario.getUsuario(), corpoRequisicao, corpoResposta.get(), ip);
					return ResponseEntity.status(HttpStatus.CREATED).body(resposta);  // Sucesso
				})
				.orElseGet(() -> {
					logService.registrarLog("POST", "/cadastrar", HttpStatus.BAD_REQUEST.value(),
							usuario.getUsuario(), corpoRequisicao, corpoResposta.get(), ip);
					return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();  // Falha
				});

		return response;
	}



	@PutMapping("/atualizar")
	public ResponseEntity<Usuario> putUsuario(@Valid @RequestBody Usuario usuario,
											  @RequestHeader("X-Forwarded-For") String ip) {
		// Salva o log da requisição
		String corpoRequisicao = usuario.toString(); // Pode ser interessante converter para um formato mais legível
		AtomicReference<String> corpoResposta = new AtomicReference<>("");  // Usando AtomicReference para contornar a limitação

		// Chama o serviço para atualizar o usuário e retorna a resposta apropriada
		ResponseEntity<Usuario> response = usuarioService.atualizarUsuario(usuario)
				.map(resposta -> {
					// Salva o corpo da resposta quando a operação for bem-sucedida
					corpoResposta.set(resposta.toString());  // Modifica o valor usando set
					logService.registrarLog("PUT", "/atualizar", HttpStatus.OK.value(),
							usuario.getUsuario(), corpoRequisicao, corpoResposta.get(), ip);
					return ResponseEntity.status(HttpStatus.OK).body(resposta);  // Sucesso
				})
				.orElseGet(() -> {
					logService.registrarLog("PUT", "/atualizar", HttpStatus.NOT_FOUND.value(),
							usuario.getUsuario(), corpoRequisicao, corpoResposta.get(), ip);
					return ResponseEntity.status(HttpStatus.NOT_FOUND).build();  // Falha
				});

		return response;
	}


	@PatchMapping("/atualizar-parcial")
	public ResponseEntity<Usuario> patchUsuario(@RequestBody UsuarioUpdateDTO dto,
												@RequestHeader("X-Forwarded-For") String ip) {
		// Salva o log da requisição
		String corpoRequisicao = dto.toString(); // Pode ser interessante converter para um formato mais legível
		AtomicReference<String> corpoResposta = new AtomicReference<>("");  // Usando AtomicReference

		return usuarioService.atualizarParcial(dto)
				.map(resposta -> {
					corpoResposta.set(resposta.toString());  // Modifica o valor usando set
					logService.registrarLog("PATCH", "/atualizar-parcial", HttpStatus.OK.value(),
							dto.getUsuario(), corpoRequisicao, corpoResposta.get(), ip);
					return ResponseEntity.status(HttpStatus.OK).body(resposta);  // Sucesso
				})
				.orElseGet(() -> {
					logService.registrarLog("PATCH", "/atualizar-parcial", HttpStatus.NOT_FOUND.value(),
							dto.getUsuario(), corpoRequisicao, corpoResposta.get(), ip);
					return ResponseEntity.status(HttpStatus.NOT_FOUND).build();  // Falha
				});
	}



	// Endpoint para autenticação do usuário, recebendo credenciais para login
	@PostMapping("/logar")
	public ResponseEntity<UsuarioLogin> autenticarUsuario(@Valid @RequestBody Optional<UsuarioLogin> usuarioLogin) {
		// Chama o serviço de autenticação, passando as credenciais do usuário.
		return usuarioService.autenticarUsuario(usuarioLogin)
				// Se a autenticação for bem-sucedida, retorna o token com status 200 OK.
				.map(resposta -> ResponseEntity.status(HttpStatus.OK).body(resposta))
				// Se falhar, retorna status 401 UNAUTHORIZED.
				.orElse(ResponseEntity.status(HttpStatus.UNAUTHORIZED).build());
	}

	@ResponseStatus(HttpStatus.NO_CONTENT)
	@DeleteMapping("/{id}")
	public void delete(@PathVariable Long id,
					   @RequestHeader("X-Forwarded-For") String ip) {
		// Aqui não é necessário o corpo da resposta, pois o método é void
		String corpoRequisicao = "ID: " + id;
		String corpoResposta = "Usuário deletado com sucesso";  // Mensagem simples de sucesso, pode ser ajustada conforme a resposta real

		usuarioService.deletarUsuarioComNotificacao(id);
		logService.registrarLog("DELETE", "/{id}", HttpStatus.NO_CONTENT.value(),
				"Usuário de ID: " + id, corpoRequisicao, corpoResposta, ip);
	}


}
