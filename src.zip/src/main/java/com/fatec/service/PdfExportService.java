package com.fatec.service;

import com.fatec.model.InfoJogos;
import com.fatec.model.Dependente;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;


@Service
public class PdfExportService {
    public void exportDataToPdf(List<InfoJogos> data, Dependente dependente, ByteArrayOutputStream byteArrayOutputStream) throws DocumentException, IOException {
        Document document = new Document();
        PdfWriter writer = PdfWriter.getInstance(document, byteArrayOutputStream);
        document.open();

        // Cabeçalho com as informações do dependente
        Paragraph header = new Paragraph("Relatório de Dados");
        document.add(header);
        document.add(Chunk.NEWLINE);

        // Dados do Dependente
        document.add(new Paragraph("Nome do Dependente: " + dependente.getNome()));
        document.add(new Paragraph("Idade: " + dependente.getIdade()));
        document.add(Chunk.NEWLINE);

        // Dados de InfoJogos
        for (InfoJogos entity : data) {
            document.add(new Paragraph("ID do Jogo: " + entity.getId()));
            document.add(new Paragraph("Tempo Total: " + entity.getTempoTotal()));
            document.add(new Paragraph("Tentativas: " + entity.getTentativas()));
            document.add(new Paragraph("Acertos: " + entity.getAcertos()));
            document.add(new Paragraph("Erros: " + entity.getErros()));
            document.add(Chunk.NEWLINE);
        }

        document.close();
    }

}
