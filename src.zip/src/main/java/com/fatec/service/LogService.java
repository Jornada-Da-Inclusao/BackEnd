package com.fatec.service;

import com.fatec.model.Log;
import com.fatec.repository.LogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;

@Service
public class LogService {

    @Autowired
    private LogRepository logRepository;

    public void registrarLog(String metodo, String endpoint, int status, String usuario, String corpoRequisicao, String corpoResposta, String ipCliente) {
        Log log = new Log();
        log.setMetodo(metodo);
        log.setEndpoint(endpoint);
        log.setStatus(status);
        log.setUsuario(usuario);
        log.setCorpoRequisicao(corpoRequisicao);
        log.setCorpoResposta(corpoResposta);
        log.setIpCliente(ipCliente);
        log.setDataHora(new Date());

        logRepository.save(log);
    }
}
